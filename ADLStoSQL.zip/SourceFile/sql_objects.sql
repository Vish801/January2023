-- Databricks notebook source
create database if not exists adls2sql;

-- COMMAND ----------

show databases;

-- COMMAND ----------

describe database adls2sql;
--describe database extended adls2sql;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC Current Database

-- COMMAND ----------

select current_database();

-- COMMAND ----------

-- MAGIC %md
-- MAGIC I will be using **adls2sql** database

-- COMMAND ----------

use adls2sql;

-- COMMAND ----------

select current_database();

-- COMMAND ----------

show tables;

-- COMMAND ----------

create table if not exists adls2sql.bank_table(
age INT,
job STRING,
marital STRING,
education STRING,
default STRING,
balance INT,
housing STRING,
loan STRING,
contact STRING,
day INT,
month STRING,
duration INT,
campaign INT,
pdays INT,
previous INT,
poutcome STRING,
y STRING
);

-- COMMAND ----------


