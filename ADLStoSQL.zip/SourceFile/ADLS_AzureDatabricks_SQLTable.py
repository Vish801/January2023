# Databricks notebook source
# MAGIC %md
# MAGIC **Mounting ADLS container to use it on Azure Databricks**
# MAGIC 
# MAGIC Below notebook run will run the notebook **mount_storage** and return the mount path. This is the same path where i have places the file **bank.csv** for this project.

# COMMAND ----------

dbutils.notebook.run('/VISH/mount_storage',60)

# COMMAND ----------

from pyspark.sql import SparkSession
spark=SparkSession.builder.master('local').appName('ADLS to SQL Table').getOrCreate()

# COMMAND ----------

bnk_rdd=spark.sparkContext.textFile('/mnt/databricksvishdl/adls-container-vish/bank.csv')

# COMMAND ----------

bnk_rdd.top(10)

# COMMAND ----------

bnk_rdd2=bnk_rdd.map(lambda x: x.split(";"))
bnk_rdd2.top(10)

# COMMAND ----------

header = bnk_rdd2.first()
bnk_rdd3=bnk_rdd2.filter(lambda line: line != header)

# COMMAND ----------

bnk_rdd3.top(10)

# COMMAND ----------

#for simplicity, creating schema as below, we can use StructField and StructType instead.

bnk_schema=["age","job","marital","education","default","balance","housing","loan","contact","day","month","duration","campaign","pdays","previous","poutcome","y"]

bnk_df=bnk_rdd3.toDF(bnk_schema)

# COMMAND ----------

from pyspark.sql import functions as F
bnk_df2=bnk_df.withColumn("age", F.regexp_replace("age", "\"", "")).withColumn("job", F.regexp_replace("job", "\"", "")).withColumn("marital", F.regexp_replace("marital", "\"", "")).withColumn("education", F.regexp_replace("education", "\"", "")).withColumn("default", F.regexp_replace("default", "\"", "")).withColumn("balance", F.regexp_replace("balance", "\"", "")).withColumn("housing", F.regexp_replace("housing", "\"", "")).withColumn("loan", F.regexp_replace("loan", "\"", "")).withColumn("contact", F.regexp_replace("contact", "\"", "")).withColumn("day", F.regexp_replace("day", "\"", "")).withColumn("month", F.regexp_replace("month", "\"", "")).withColumn("duration", F.regexp_replace("duration", "\"", "")).withColumn("campaign", F.regexp_replace("campaign", "\"", "")).withColumn("pdays", F.regexp_replace("pdays", "\"", "")).withColumn("previous", F.regexp_replace("previous", "\"", "")).withColumn("poutcome", F.regexp_replace("poutcome", "\"", "")).withColumn("y", F.regexp_replace("y", "\"", ""))

# COMMAND ----------

# MAGIC %md
# MAGIC **Final Dataframe which will be loaded to SQL Database**

# COMMAND ----------

bnk_df2.show(10, truncate=False)

# COMMAND ----------

# MAGIC %md
# MAGIC Below Notebook in %run will run the notebook **sql_objects** and create database and tables, also variable or results in the notebook will be returned to current notebook.

# COMMAND ----------

# MAGIC %run /VISH/sql_objects

# COMMAND ----------

# MAGIC %md
# MAGIC Creating temporary view, this view will be used to load the data to main database table.

# COMMAND ----------

bnk_df2.createOrReplaceTempView('bank_temp_view')

# COMMAND ----------

# MAGIC %md
# MAGIC Inserting data from temp view to **adls2sql.bank_table** table.

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO adls2sql.bank_table
# MAGIC SELECT * FROM bank_temp_view;

# COMMAND ----------

# MAGIC %sql
# MAGIC --select * from adls2sql.bank_table limit 10;
# MAGIC select count(1) from bank_table;

# COMMAND ----------

# MAGIC %md
# MAGIC Dropping table as purpose of this project completed.

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table adls2sql.bank_table;
