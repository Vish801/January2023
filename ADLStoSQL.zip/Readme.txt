NOTE: 

Open source files present in folder 'SourceFile' using Databricks / AzureDatabricks for better view.

Content of folder 'SourceFile':
	* ADLS_AzureDatabricks_SQLTable
	* mount_storage.py
	* sql_objects.py

To maintain the proper flow of program, I have called the other two notebooks 
from the 'ADLS_AzureDatabricks_SQLTable' notebook. 